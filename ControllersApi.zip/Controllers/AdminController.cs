﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.IO;
using Domain;
using Infrastructure;

namespace WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {
        private readonly string connectionString = "Server=(localdb)\\mssqllocaldb;Database=userAuthantication;Trusted_Connection=True;MultipleActiveResultSets=true";
        private readonly ILogger<AdminController> _logger;
        private readonly IWebHostEnvironment _env;
        private readonly IRepository<Apply> _app;
        private readonly IRepository<Job> _jo;

        public AdminController(ILogger<AdminController> logger, IWebHostEnvironment env, IRepository<Apply> a, IRepository<Job> j)
        {
            _logger = logger;
            _env = env;
            _app = a;
            _jo = j;
        }

        [HttpGet("cookies-message")]
        //public IActionResult GetCookiesMessage()
        //{
        //    string message;
        //    if (HttpContext.Request.Cookies.ContainsKey("visit"))
        //    {
        //        string data = HttpContext.Request.Cookies["visit"];
        //        message = $"You Visited our website at {data}";
        //    }
        //    else
        //    {
        //        CookieOptions cookieOptions = new CookieOptions
        //        {
        //            Expires = DateTime.Now.AddDays(2)
        //        };
        //        HttpContext.Response.Cookies.Append("visit", DateTime.Now.ToString());
        //        message = "You visited First Time";
        //    }

        //    return Ok(message);
        //}

        //[HttpDelete("privacy")]
        //public IActionResult DeletePrivacyCookie()
        //{
        //    HttpContext.Response.Cookies.Delete("first_visit");
        //    return NoContent();
        //}

        [HttpPost("add-job")]
        public IActionResult AddNewJob([FromForm] Job job)
        {
            job.ImageURL = SaveImageAsync(job.Image);
            _jo.Add(job);
            return Ok(new { message = "Job added successfully." });
        }

        private string SaveImageAsync(IFormFile picture)
        {
            string imageFolder = Path.Combine(_env.WebRootPath, "dummy");
            if (!Directory.Exists(imageFolder))
                Directory.CreateDirectory(imageFolder);
            if (picture == null)
            {
                return Path.Combine(imageFolder, "dummy");
            }
            string uniqueFileName = picture.FileName;
            string filePath = Path.Combine(imageFolder, uniqueFileName);
            using (var fileStream = new FileStream(filePath, FileMode.Create))
            {
                picture.CopyTo(fileStream);
            }
            return Path.Combine("dummy", uniqueFileName);
        }

        [HttpGet("view-all-jobs")]
        public IActionResult ViewAllJobs()
        {
            List<Job> jobs = _jo.viewAll();
            return Ok(jobs);
        }

        [HttpDelete("delete-job/{id}")]
        public IActionResult DeleteJob(int id)
        {
            _jo.Delete(id);
            return Ok(new { message = "Job deleted successfully." });
        }

        [HttpGet("job-details/{id}")]
        public IActionResult DetailOfJob(int id)
        {
            var job = _jo.findById(id);
            if (job == null)
            {
                return NotFound(new { message = "Job not found." });
            }
            return Ok(job);
        }

        [HttpPut("update-job/{id}")]
        public IActionResult UpdateJob(int id, [FromForm] Job job)
        {
            job.Id = id;
            job.ImageURL = SaveImageAsync(job.Image);
            _jo.Update(job);
            return Ok(new { message = "Job updated successfully." });
        }

        //[HttpGet("view-all-registered-users")]
        //public IActionResult ViewAllRegisteredUsers()
        //{
        //    var users = _user.viewAll();
        //    return Ok(users);
        //}
    }
}
