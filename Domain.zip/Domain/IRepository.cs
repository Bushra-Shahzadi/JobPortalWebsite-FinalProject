﻿namespace Domain
{
    public interface IRepository<TEntity>
    {
        public void Add(TEntity entity);
        public void Update(TEntity entity);
        public Task Delete(int id);
        public TEntity findById(int id);
        public List<TEntity> viewAll();
    }
}
