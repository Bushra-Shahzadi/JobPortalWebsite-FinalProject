﻿using Microsoft.VisualBasic;

namespace Domain
{
    public class JobApply
    {
        public Job job { get; set; }
        public Apply apply { get; set; }
    }
}
