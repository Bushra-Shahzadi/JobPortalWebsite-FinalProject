﻿using Microsoft.AspNetCore.Identity;

namespace Domain
{
    public class CustomFields:IdentityUser
    {
        public string role {  get; set; }
        public string name { get; set; }
        public string Country { get; set; }
        public string cnic {  get; set; }
        
    }
}
