﻿using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Http;
namespace Domain
{
    public class Job
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string JobType { get; set; }
        public string Qualification { get; set; }
        public decimal Salary { get; set; }
        public DateTime Deadline { get; set; }
        public IFormFile Image { get; set; }
        public string ImageURL { get; set; }
    }
}
