﻿using Application;
using Microsoft.AspNetCore.DataProtection.KeyManagement.Internal;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using userAuthentication.Data;
using userAuthentication.Models;

namespace userAuthentication.Controllers
{
    public class AdminController : Controller
    {
        private readonly string connectionString = "Server=(localdb)\\mssqllocaldb;Database=userAuthantication;Trusted_Connection=True;MultipleActiveResultSets=true";
        private readonly CustomMapper<Domain.Job, userAuthentication.Models.Job> _jobmapper;
        private readonly JobService _jobService;
        private readonly ILogger<AdminController> _logger;
        private readonly IWebHostEnvironment _env;
        private readonly IHubContext<ChatHub> _hubContext;


        private readonly IMemoryCache _memoryChache;
        public AdminController(ILogger<AdminController> logger, IWebHostEnvironment env, JobService jobService, IHubContext<ChatHub> hubContext, IMemoryCache chache)
        {

            _logger = logger;
            _env = env;
            _jobService = jobService;
            _jobmapper = new CustomMapper<Domain.Job, userAuthentication.Models.Job>();
            _hubContext = hubContext;
            _memoryChache = chache;
        }

        public async Task<IActionResult> Index()
        {
            string message = string.Empty;
            if (HttpContext.Request.Cookies.ContainsKey("visit"))
            {
                string data = HttpContext.Request.Cookies["visit"];
                message = $"You Visited our website at {data}";
            }
            else
            {
                CookieOptions cookieOptions = new CookieOptions
                {
                    Expires = DateTime.Now.AddDays(2)
                };
                HttpContext.Response.Cookies.Append("visit", DateTime.Now.ToString());
                message = "You visited First Time";
            }

            return View("_AddCookie");
        }

        public IActionResult Privacy()
        {
            HttpContext.Response.Cookies.Delete("first_visit");
            return View();
        }

        public IActionResult AddNewJob()
        {
            return View();
        }


        [HttpPost]
        public async Task<ActionResult> AddNewJob(Job job)
        {
            job.ImageURL = SaveImageAsync(job.Image);
            _jobService.AddJob(_jobmapper.WebToDomain(job));

            // Send SignalR notification
            await _hubContext.Clients.All.SendAsync("AddJobNotification", job.Title, job.Salary, job.JobType);

            return RedirectToAction("ViewAllJobs", "Admin");
        }

        private string SaveImageAsync(IFormFile picture)
        {
            string imageFolder = Path.Combine(_env.WebRootPath, "dummy");
            if (!Directory.Exists(imageFolder))
                Directory.CreateDirectory(imageFolder);
            if (picture == null)
            {
                return Path.Combine(imageFolder, "dummy");
            }
            string uniqueFileName = picture.FileName;
            string filePath = Path.Combine(imageFolder, uniqueFileName);
            using (var fileStream = new FileStream(filePath, FileMode.Create))
            {
                picture.CopyTo(fileStream);
            }
            return Path.Combine("dummy", uniqueFileName);
        }

        public async Task<IActionResult> ViewAllJobs()
        {
            var chacheKey = "abc";
            var domainJobs = _jobService.GetAlJobs().ToList();
            List<Job> webJobs = new List<Job>();
            if (!_memoryChache.TryGetValue(chacheKey, out webJobs))
            {
                webJobs = await _jobmapper.GetAll(domainJobs);
                var cacheEntryOptions = new MemoryCacheEntryOptions
                {
                    AbsoluteExpirationRelativeToNow = TimeSpan.FromSeconds(1)
                };
                _memoryChache.Set(chacheKey, webJobs, cacheEntryOptions);
            }
            return View(webJobs);
        }

        public async Task<IActionResult> DeleteJob(int id)
        {
            await _jobService.Delete(id);
            return RedirectToAction("ViewAllJobs", "Admin");
        }

        public IActionResult UpdateJob(int id)
        {
            var domainJob = _jobService.findJobById(id);
            var webJob = _jobmapper.DomainToWeb(domainJob);
            TempData["Id"] = id;
            return View(webJob);
        }

        [HttpPost]
        public IActionResult UpdateJob(Job job)
        {
            job.Id = Convert.ToInt32(TempData["Id"].ToString());
            job.ImageURL = SaveImageAsync(job.Image);
            _jobService.UpdateJob(_jobmapper.WebToDomain(job));
            return RedirectToAction("ViewAllJobs", "Admin");
        }

        public IActionResult DetailOfJob(int id)
        {
            var domainJob = _jobService.findJobById(id);
            var webJob = _jobmapper.DomainToWeb(domainJob);
            return View(webJob);
        }

        [HttpGet]
        public async Task<IActionResult> Search(string jobName)
        {
            if (string.IsNullOrEmpty(jobName))
            {
                return PartialView("_AddViewModel", new List<Job>());
            }

            var domainJobs = _jobService.GetAlJobs()
                                        .Where(j => j.Title.Contains(jobName, StringComparison.OrdinalIgnoreCase))
                                        .ToList();

            var webJobs = await _jobmapper.GetAll(domainJobs);
            return PartialView("_AddViewModel", webJobs);
        }
    }
}



















//using Application;
//using Microsoft.AspNetCore.Authorization;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.CodeAnalysis.CSharp.Syntax;
//using Microsoft.VisualBasic;
//using System.Configuration;
//using System.Runtime.CompilerServices;
//using System.Security.Cryptography.Xml;
//using userAuthentication.Models;

//namespace userAuthentication.Controllers
//{
//   // [Authorize(Policy = "AdminPolicy")]
//    public class AdminController : Controller
//    {

//        private readonly string connectionString = "Server=(localdb)\\mssqllocaldb;Database=userAuthantication;Trusted_Connection=True;MultipleActiveResultSets=true";

//        private readonly CustomMapper<Domain.Job, userAuthentication.Models.Job> _jobmapper = new CustomMapper<Domain.Job, Models.Job>();
//        private JobService _jobService;
//        //private readonly CustomMapper<Domain.Apply, userAuthentication.Models.Apply> _applymapper = new CustomMapper<Domain.Apply, Models.Apply>();
//        //private ApplyService _applyService;
//        private readonly ILogger<AdminController> _logger;
//        private readonly IWebHostEnvironment _env;
//        //private readonly IRepository<Apply> _app;
//        //private readonly IRepository<Job> _jo;
//        //private readonly IRepository<RegisteredUsers> _user;
//        public AdminController(ILogger<AdminController> logger, IWebHostEnvironment env ,/* ApplyService a ,*/ JobService j /*IRepository<RegisteredUsers> u*/)
//        {
//            _logger = logger;
//            _env = env;
//            //_applyService = a;   
//            _jobService = j;
//            //_user = u;
//        }
//        public IActionResult Index()
//        {
//            string message = string.Empty;
//            if (HttpContext.Request.Cookies.ContainsKey("visit"))
//            {
//                string data = HttpContext.Request.Cookies["visit"];
//                message = $"You Visited our website at {data}";

//            }
//            else
//            {
//                CookieOptions cookieOptions = new CookieOptions();
//                cookieOptions.Expires = DateTime.Now.AddDays(2);
//                HttpContext.Response.Cookies.Append("visit", DateTime.Now.ToString());
//                message = "You visited First Time";
//            }

//            return View("_AddCookie");

//        }
//        public IActionResult Privacy()
//        {

//            HttpContext.Response.Cookies.Delete("first_visit");
//            return View();
//        }
//        public IActionResult AddNewJob()
//        {   
//            return View();
//        }
//        [HttpPost]

//        public IActionResult AddNewJob(Job job)
//        {
//            job.ImageURL = saveImageAsync(job.Image);
//            //IRepository<Job> j = new GenericRepository<Job>(connectionString);
//            //j.Add(job);
//            _jobService.Add(_jobmapper.WebToDomain(job));
//            return RedirectToAction("ViewAllJobs", "Admin");
//        }

//        private string saveImageAsync(IFormFile picture)
//        {
//            string imageFolder = Path.Combine(_env.WebRootPath, "dummy");
//            if (!Directory.Exists(imageFolder))
//                Directory.CreateDirectory(imageFolder);
//            if (picture == null)
//            {
//                return Path.Combine(imageFolder, "dummy");
//            }
//            string uniqueFileName = picture.FileName;
//            string filePath = Path.Combine(imageFolder, uniqueFileName);
//            using (var fileStream = new FileStream(filePath, FileMode.Create))
//            {
//                picture.CopyTo(fileStream);
//            }
//            return Path.Combine("dummy", uniqueFileName);
//        }
//        public IActionResult ViewAllJobs()
//        {
//            List<userAuthentication.Models.Job> data=new List<userAuthentication.Models.Job>();
//            //IRepository<Job> j = new GenericRepository<Job>(connectionString);
//            data = _jobmapper.GetAll(_jobService.GetAllJobs());
//            //List<Job> jobs = _jo.viewAll();
//            return View(data);
//        }
//        public IActionResult DeleteJob(int id)
//        {
//            //IRepository<Job> j = new GenericRepository<Job>(connectionString);
//            //j.Delete(id);
//            _jo.Delete(id);
//            return RedirectToAction("ViewAllJobs", "Admin");
//        }
//        public IActionResult UpdateJob(int id)
//        {
//            //Job job = new Job();
//            //GenericRepository<Job> grepo = new GenericRepository<Job>(connectionString);
//            //job = grepo.findById(id);
//            _jobService.UpdateJob(_jobmapper.WebToDomain(Job));
//            //var job= _jo.findById(id);
//            //TempData["Id"] = id;
//            return View(job);
//        }
//        [HttpPost]
//        public IActionResult Updatejob(Job job)
//        {
//            job.Id = Convert.ToInt32( TempData["Id"].ToString());
//            job.ImageURL = saveImageAsync(job.Image);
//            //IRepository<Job> j = new GenericRepository<Job>(connectionString);
//            //j.Update(job);
//            _jo.Update(job);
//            return RedirectToAction("ViewAllJobs","Admin");
//        }
//        //public IActionResult ViewAllRegisteredUsers()
//        //{
//        //    //RegisteredUsersRepository user=new RegisteredUsersRepository();
//        //    //user.viewUsers();
//        //    _user.viewAll();
//        //    return View();
//        //}

//        public IActionResult DetailOfJob(int ID)
//        {
//            //IRepository<Job> job = new GenericRepository<Job>(connectionString);
//            //return View(job.findById(ID));
//            return View(_jo.findById(ID));
//        }
//    }
//}
