﻿using Microsoft.AspNetCore.Mvc;

namespace userAuthentication.Controllers
{
    public class UserController : Controller
    {
        public IActionResult Login()
        {
            return View();
        }
        public IActionResult Signup()
        {
            return View();
        }
        public IActionResult Forget()
        {
            return View();
        }
    }
}
