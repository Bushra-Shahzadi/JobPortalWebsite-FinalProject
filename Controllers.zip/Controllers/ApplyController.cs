﻿using Microsoft.AspNetCore.Mvc;

namespace userAuthentication.Controllers
{
    public class ApplyController : Controller
    {
        public IActionResult ViewJobs()
        {
            return View();
        }
        public IActionResult ViewDetail()
        {
            return View();
        }
        public IActionResult Apply()
        {
            return View();
        }
    }
}
