using userAuthentication.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using Microsoft.AspNetCore.Authorization;
using Microsoft.JSInterop;
using Microsoft.EntityFrameworkCore.Metadata.Conventions;
using System.Threading.Tasks.Dataflow;
using userAuthentication.Controllers;
using Microsoft.Identity.Client;
using Application;
using userAuthentication.Models;

namespace identity.Controllers
{
    public class HomeController : Controller
    {
        private readonly string connectionString = "Server=(localdb)\\mssqllocaldb;Database=userAuthantication;Trusted_Connection=True;MultipleActiveResultSets=true";

        private readonly ILogger<HomeController> _logger;
        private readonly IWebHostEnvironment _env;

        public HomeController(ILogger<HomeController> logger, IWebHostEnvironment env)
        {
            _logger = logger;
            _env = env;
        }

        public IActionResult Index()
        {
            return View();
        }
        private string saveImageAsync(IFormFile picture)
        {
            string imageFolder = Path.Combine(_env.WebRootPath, "dummy");
            if (!Directory.Exists(imageFolder))
                Directory.CreateDirectory(imageFolder);
            if (picture == null)
            {
                return Path.Combine(imageFolder, "dummy");
            }
            string uniqueFileName = picture.FileName;
            string filePath = Path.Combine(imageFolder, uniqueFileName);
            using (var fileStream = new FileStream(filePath, FileMode.Create))
            {
                picture.CopyTo(fileStream);
            }
            return Path.Combine("dummy", uniqueFileName);
        }
        public IActionResult About()
        {
            return View();
        }
        public IActionResult Contact()
        {
            return View();
        }
        public IActionResult Jobs()
        {
            return View();
        }
        public IActionResult Details()
        {
            return View();
        }
        //[Authorize(Policy = "ApplyHourPolicy")]
        //[Authorize(Policy = "CountryPolicy")]
        public IActionResult Apply()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Apply(Apply a)
        {
            if (ModelState.IsValid)
            {
                // Log the state of the model
                var errors = ModelState.Values.SelectMany(v => v.Errors);
                foreach (var error in errors)
                {
                    // Log or inspect errors
                    // For example: _logger.LogError($"Validation Error: {error.ErrorMessage}");
                    Console.WriteLine($"Validation Error: {error.ErrorMessage}");
                }
            }
            else
            {

                // Ensure saveImageAsync is awaited
                a.Profile = saveImageAsync(a.Image);
                a.Resume = saveImageAsync(a.ResumeFile);

                GenericRepository<Apply> repo = new GenericRepository<Apply>(connectionString);
                repo.Add(a);

                return RedirectToAction("ViewModel", "Home");
            }
            return View(a);
        }



        public IActionResult ViewModel(int id)
        {
            GenericRepository<Apply> i = new GenericRepository<Apply>(connectionString);
            Apply a = i.findById(id);

            return View(a);
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

    }











    //public class HomeController : Controller
    //{
    //    private readonly string connectionString = "Server=(localdb)\\mssqllocaldb;Database=userAuthantication;Trusted_Connection=True;MultipleActiveResultSets=true";
    //    //private readonly CustomMapper<Domain.Apply, userAuthentication.Models.Apply> _applymapper = new CustomMapper<Domain.Apply, userAuthentication.Models.Apply>();
    //    //private ApplyService _applyService;
    //    private readonly 
    //    private readonly ILogger<HomeController> _logger;
    //    private readonly IWebHostEnvironment _env;

    //    public  HomeController(ILogger<HomeController> logger, IWebHostEnvironment env, ApplyService a)
    //    {
    //        _logger = logger;
    //        _env = env;
    //        _applyService = a;
    //    }

    //    public IActionResult Index()
    //    {
    //        return View();
    //    }
    //    private string saveImageAsync(IFormFile picture)
    //    {
    //        string imageFolder = Path.Combine(_env.WebRootPath, "dummy");
    //        if (!Directory.Exists(imageFolder))
    //            Directory.CreateDirectory(imageFolder);
    //        if (picture == null)
    //        {
    //            return Path.Combine(imageFolder, "dummy");
    //        }
    //        string uniqueFileName = picture.FileName;
    //        string filePath = Path.Combine(imageFolder, uniqueFileName);
    //        using (var fileStream = new FileStream(filePath, FileMode.Create))
    //        {
    //            picture.CopyTo(fileStream);
    //        }
    //        return Path.Combine("dummy", uniqueFileName);
    //    }
    //    public IActionResult About()
    //    {
    //        return View();
    //    }
    //    public IActionResult Contact()
    //    {
    //        return View();
    //    }
    //    public IActionResult Jobs()
    //    {
    //        return View();
    //    }
    //    public IActionResult Details()
    //    {
    //        return View();
    //    }
    //   //[Authorize(Policy = "ApplyHourPolicy")]
    //    //[Authorize(Policy = "CountryPolicy")]
    //    public IActionResult Apply()
    //    {
    //        return View();
    //    }
    //    [HttpPost]
    //    public async Task<IActionResult> Apply(Apply a)
    //    {
    //        if (ModelState.IsValid)
    //        {
    //            // Log the state of the model
    //            var errors = ModelState.Values.SelectMany(v => v.Errors);
    //            foreach (var error in errors)
    //            {
    //                // Log or inspect errors
    //                // For example: _logger.LogError($"Validation Error: {error.ErrorMessage}");
    //                Console.WriteLine($"Validation Error: {error.ErrorMessage}");
    //            }
    //        }
    //        else
    //        {

    //            // Ensure saveImageAsync is awaited
    //            a.Profile = saveImageAsync(a.Image);
    //            a.Resume = saveImageAsync(a.ResumeFile);

    //            //GenericRepository<Apply> repo = new GenericRepository<Apply>(connectionString);
    //            //repo.Add(a);
    //            _applyService.ApplyJob(_applymapper.WebToDomain(a));
    //            return RedirectToAction("ViewModel", "Home");
    //        }
    //        return View(a);
    //    }



    //    public IActionResult ViewModel(int id)
    //    {
    //        var domainJob = _applyService.ViewJobById(id);
    //        var webJob = _applymapper.DomainToWeb(domainJob);
    //        //Apply a=i.findById(id);

    //        return View(webJob);
    //    }


    //    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    //    public IActionResult Error()
    //    {
    //        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    //    }

    //}
}
