﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Domain;

namespace Application
{
    public class ApplyService
    {
        private readonly IRepository<Apply> _applyRepository;

        public  ApplyService(IRepository<Apply> applyRepository)
        {
            _applyRepository = applyRepository;
        }

        public IEnumerable<Apply> ViewAllJobs()
        {
            return _applyRepository.viewAll();
        }

        public Apply ViewJobById(int id)
        {
            return _applyRepository.findById(id);
        }

        public void ApplyJob(Apply apply)
        {
            _applyRepository.Add(apply);
        }

        public void UpdateApply(Apply apply)
        {
            _applyRepository.Update(apply);
        }

        public void DeleteApply(int id)
        {
            _applyRepository.Delete(id);
        }
    }
}
