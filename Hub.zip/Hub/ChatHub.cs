﻿using Microsoft.AspNetCore.SignalR;
namespace userAuthentication.Models
{ 
    public class ChatHub:Hub
    {
        public async Task SendProductNotification(string jobName, decimal salary, string jobType)
        {
            await Clients.All.SendAsync("AddJobNotification", jobName, salary, jobType);
        }
    }
}
