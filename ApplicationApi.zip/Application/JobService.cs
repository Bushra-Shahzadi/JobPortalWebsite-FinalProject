﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Domain;


namespace Application
{
    public class JobService
    {
     
        private readonly IRepository<Job> _jobRepository;

        public JobService(IRepository<Job> jobRepository)
        {
            _jobRepository = jobRepository;
        }

        public IEnumerable<Job> GetAlJobs()
        {
            return _jobRepository.viewAll();
        }

        public Job findJobById(int id)
        {
            return _jobRepository.findById(id);
        }

        public void AddJob(Job job)
        {
            _jobRepository.Add(job);
        }

        public void UpdateJob(Job job)
        {
            _jobRepository.Update(job);
        }

        public async Task Delete(int id)
        {
            await _jobRepository.Delete(id);
        }
    }
}
