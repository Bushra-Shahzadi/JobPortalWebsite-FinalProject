﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using userAuthentication.Models;

namespace userAuthentication.Data
{
    public class ApplicationDbContext : IdentityDbContext<CustomFields>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
    }
}
