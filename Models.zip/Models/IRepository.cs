﻿namespace userAuthentication.Models
{
    public interface IRepository<TEntity>
    {
        public void Add(TEntity entity);
        public void Update(TEntity entity);
        public void Delete(int id);
        public TEntity findById(int id);
        public List<TEntity> viewAll();
    }
}
