﻿using System.ComponentModel.DataAnnotations;

namespace userAuthentication.Models
{
    public class Apply
    {
        public int Id { get; set; }
        [Required]
        [AllowedWordsAttribute("^[a-zA-Z]+$")]
        public string Name { get; set; }
        [Required]
        [EmailAddress]  
        public string Email { get; set; }
        [Required]
        public IFormFile Image { get; set; }
        [Required]
        public IFormFile ResumeFile { get; set; }
        public string Profile {  get; set; }
        public string Resume { get; set; }
        
    }
}
