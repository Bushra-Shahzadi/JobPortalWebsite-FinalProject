﻿using System.ComponentModel.DataAnnotations;
using System.Text.RegularExpressions;

namespace userAuthentication.Models
{
    public class AllowedWordsAttribute : ValidationAttribute
    {
        private readonly string _pattern;

        public AllowedWordsAttribute(string pattern)
        {
            _pattern = pattern;
        }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value is string stringValue)
            {
                if (!Regex.IsMatch(stringValue, _pattern))
                {
                    return new ValidationResult($"The field contains invalid characters. Only alphabets are allowed.");
                }
            }
            return ValidationResult.Success;
        }
    }
}
