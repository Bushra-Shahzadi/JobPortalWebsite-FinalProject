﻿using Dapper;
using Microsoft.Data.SqlClient;
using System.Reflection;
using System.Reflection.Metadata.Ecma335;
using System.Runtime.InteropServices;
using static Dapper.SqlMapper;
using System.Diagnostics;

namespace userAuthentication.Models
{
    public class GenericRepository<TEntity> : IRepository<TEntity>
    {
        private readonly string connectionString;
        public GenericRepository(string c)
        {
            connectionString = c;
        }
        public void Add(TEntity entity)//correct
        {
            try
            {
                // Getting Name of Object/Table
                var tableName = typeof(TEntity).Name;
                //Getting Properties 
                var properties = typeof(TEntity).GetProperties().Where(p => p.Name != "Id" && p.PropertyType != typeof(IFormFile));
                //Getting Coloum Names
                var coloumNames = string.Join(",", properties.Select(p => p.Name));
                var parametersName = string.Join(",", properties.Select(p => "@" + p.Name));
                var query = $"insert into {tableName} ({coloumNames}) values ({parametersName})";
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    var cmd = new SqlCommand(query, connection);
                    foreach (var prob in properties)
                    {
                        cmd.Parameters.AddWithValue("@" + prob.Name, prob.GetValue(entity));
                    }
                    cmd.ExecuteNonQuery();
                }
            }//debug kron??
            catch (Exception ex)
            {
                //Trace.WriteLine($"Trace: Exception type: {ex.GetType}, Message: {ex.Message}");
                //Debug.WriteLine($"Debug: Exception type: {ex.GetType}, Message: {ex.Message}");
            }
}
        public void Update(TEntity entity)//correct
        {
            try
            {
                var tableName = typeof(TEntity).Name;
                var primaryKey = "Id";
                var properties = typeof(TEntity).GetProperties().Where(p => p.Name != primaryKey && p.PropertyType != typeof(IFormFile));
                var parametersName = string.Join(",", properties.Select(p => $"{p.Name}=@{p.Name}"));
                var query = $"update {tableName} set {parametersName} where {primaryKey}=@{primaryKey}";
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    connection.Execute(query, entity);
                }
            }
            catch(Exception ex) 
            {
                //Trace.WriteLine($"Trace: Exception type: {ex.GetType}, Message: {ex.Message}");
                //Debug.WriteLine($"Debug: Exception type: {ex.GetType}, Message: {ex.Message}");
            }
        }

        public void Delete(int id)//correct
        {
            try
            {
                var tableName = typeof(TEntity).Name;
                var primaryKey = "Id"; // 
                var query = $"delete from {tableName} where {primaryKey}=@id";
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    var cmd = new SqlCommand(query, connection);
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.ExecuteNonQuery();
                }
            }
            catch( Exception ex)
            {
                //Trace.WriteLine($"Trace: Exception type: {ex.GetType}, Message: {ex.Message}");
                //Debug.WriteLine($"Debug: Exception type: {ex.GetType}, Message: {ex.Message}");
            }

        }
        public List<TEntity> viewAll()
        {
            List<TEntity> entities = new List<TEntity>(); // Initialize here

            try
            {
                var tableName = typeof(TEntity).Name;
                var query = $"select * from {tableName}";
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    entities = connection.Query<TEntity>(query).ToList();
                }
            }
            catch (Exception ex)
            {
                //Trace.WriteLine($"Trace: Exception type: {ex.GetType()}, Message: {ex.Message}");
                //Debug.WriteLine($"Debug: Exception type: {ex.GetType()}, Message: {ex.Message}");
                // Optionally handle the exception here
            }

            return entities;
        }

        public TEntity findById(int id)//correct
        {
            TEntity entity= default(TEntity);
            try
            {
                var tableName = typeof(TEntity).Name;
                var primaryKey = "Id";
                var query = $"select * from {tableName} where {primaryKey}=@id";
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    entity=connection.Query<TEntity>(query, new { id = id }).FirstOrDefault();

                }
            }
            catch(Exception ex)
            {
                //Trace.WriteLine($"Trace: Exception type: {ex.GetType()}, Message: {ex.Message}");
                //Debug.WriteLine($"Debug: Exception type: {ex.GetType()}, Message: {ex.Message}");
            }
            return entity;
        }




        private TEntity MapReaderToObject(SqlDataReader reader)//correct
        {
            var entity = Activator.CreateInstance<TEntity>();
            foreach (var property in typeof(TEntity).GetProperties())
            {
                if (property.Name != "Id")
                {
                    try
                    {
                        int ordinal = reader.GetOrdinal(property.Name);
                        if (!reader.IsDBNull(ordinal))
                        {
                            var value = reader.GetValue(ordinal);
                            if (value != DBNull.Value)
                            {
                                property.SetValue(entity, Convert.ChangeType(value, property.PropertyType));
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                }
            }
            return entity;
        }
    }
}










