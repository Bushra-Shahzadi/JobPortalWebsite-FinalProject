﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace userAuthentication.Models
{
    public class CustomMapper<TDomain, TWeb> : ICustomMapper<TDomain, TWeb>
    {
        // Maps properties from a TWeb object to a TDomain object
        public TDomain WebToDomain(TWeb webEntity)
        {
            // Create a new instance of TDomain
            var domainEntity = Activator.CreateInstance<TDomain>();

            // Get properties of both types
            var domainProperties = typeof(TDomain).GetProperties();
            var webProperties = typeof(TWeb).GetProperties();

            // Iterate over domain properties and map to web properties
            foreach (var domainProp in domainProperties)
            {
                // Find a matching property in the web type
                var webProp = webProperties.FirstOrDefault(p => p.Name == domainProp.Name && p.PropertyType == domainProp.PropertyType);

                if (webProp != null)
                {
                    // Get the value from the web entity and set it to the domain entity
                    var value = webProp.GetValue(webEntity);
                    domainProp.SetValue(domainEntity, value);
                }
            }

            return domainEntity;
        }

        // Maps properties from a TDomain object to a TWeb object
        public TWeb DomainToWeb(TDomain domainEntity)
        {
            if (domainEntity == null)
            {
                throw new ArgumentNullException(nameof(domainEntity), "domainEntity cannot be null.");
            }

            var webEntity = Activator.CreateInstance<TWeb>();
            var domainProperties = typeof(TDomain).GetProperties();
            var webProperties = typeof(TWeb).GetProperties();

            foreach (var webProp in webProperties)
            {
                var domainProp = domainProperties.FirstOrDefault(p => p.Name == webProp.Name && p.PropertyType == webProp.PropertyType);

                if (domainProp != null)
                {
                    var value = domainProp.GetValue(domainEntity);
                    webProp.SetValue(webEntity, value);
                }
            }

            return webEntity;
        }


        // Converts a list of TDomain objects into a list of TWeb objects
        public async Task<List<TWeb>> GetAll(List<TDomain> domainList)
        {
            var webList = new List<TWeb>();

            // Iterate over the domain list and map each domain object to a web object
            foreach (var domainEntity in domainList)
            {
                var webEntity = DomainToWeb(domainEntity);
                webList.Add(webEntity);
            }

            return webList;
        }
    }
}
