﻿namespace userAuthentication.Models
{
    public interface ICustomMapper<TDomain,TWeb>
    {
        TDomain WebToDomain(TWeb webEntity);
        TWeb DomainToWeb(TDomain domainEntity);
        Task<List<TWeb>> GetAll(List<TDomain> domainList);
    }
}
