﻿namespace userAuthentication.Models
{
    public class RegisteredUsers
    {
        public string Name { get; set; }
        public string Email { set; get; }
        public string CNIC { get; set; }
        public string Country { get; set; }
    }
}
