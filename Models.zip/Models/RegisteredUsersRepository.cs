﻿using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.Data.SqlClient;

namespace userAuthentication.Models
{
    public class RegisteredUsersRepository
    {
        public List<RegisteredUsers> viewUsers()
        {
            List<RegisteredUsers> users = new List<RegisteredUsers>();
            try
            {
                string connection = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=userAuthantication;Integrated Security=True";
                SqlConnection con = new SqlConnection(connection);
                con.Open();
                string read = "select Email , Name , CNIC , Country from AspNetUsers";
                SqlCommand cmd = new SqlCommand(read, con);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    RegisteredUsers user = new RegisteredUsers { Email = (string)reader["Email"], Name = (string)reader["Name"], Country = (string)reader["Country"], CNIC = (string)reader["CNIC"] };
                    users.Add(user);

                }
                con.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return users;
        }
    }
}
