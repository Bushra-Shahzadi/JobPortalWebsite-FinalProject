﻿using Microsoft.VisualBasic;

namespace userAuthentication.Models
{
    public class JobApply
    {
        public Job job { get; set; }
        public Apply apply { get; set; }
    }
}
